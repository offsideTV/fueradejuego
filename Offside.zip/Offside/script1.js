// Esperar a que la API de Google Cast esté disponible
window['__onGCastApiAvailable'] = function (isAvailable) {
    if (isAvailable) {
        initializeCastApi();
    } else {
        console.error("Error: Google Cast API no disponible.");
    }
};

function initializeCastApi() {
    console.log("Google Cast API lista");

    const context = cast.framework.CastContext.getInstance();
    context.setOptions({
        receiverApplicationId: chrome.cast.media.DEFAULT_MEDIA_RECEIVER_APP_ID,
        autoJoinPolicy: chrome.cast.AutoJoinPolicy.ORIGIN_SCOPED
    });

    context.addEventListener(
        cast.framework.CastContextEventType.SESSION_STATE_CHANGED,
        (event) => {
            console.log("Estado de Chromecast:", event.sessionState);
        }
    );
}

document.getElementById("castButton").addEventListener("click", async function () {
    const context = cast.framework.CastContext.getInstance();
    const session = context.getCurrentSession();

    if (!session) {
        alert("No hay sesión de Chromecast activa.");
        return;
    }

    // Obtener la URL del video actual
    const videoUrl = document.getElementById("video-iframe").src;

    if (!videoUrl) {
        alert("No hay ningún video cargado.");
        return;
    }

    // Crear un objeto de media para Chromecast
    const mediaInfo = new chrome.cast.media.MediaInfo(videoUrl, "video/mp4");
    const request = new chrome.cast.media.LoadRequest(mediaInfo);

    session.loadMedia(request)
        .then(() => console.log("Video enviado a Chromecast"))
        .catch((error) => console.error("Error al enviar el video:", error));
});
